# 🚀 Smart Photo Estimator — Netlify Deploy Guide (Hinglish)

Ye guide follow karo aur aapka photo+AI feature **live** ho jayega kaarukranti.in pe.

---

## Aapko 3 cheezein chahiye
1. Anthropic API key (photo analysis ke liye)
2. Ye folder (jo aapko mila — index.html + netlify folder + netlify.toml)
3. Netlify account (jo aapke paas already hai)

---

## STEP 1 — Anthropic API Key lo

1. Browser mein kholo: **console.anthropic.com**
2. Sign up / login karo
3. Left menu → **Billing** → thoda credit add karo (₹400-800 se shuru, pay-as-you-go)
   - Har photo analysis ~₹1-3 lagega
4. Left menu → **API Keys** → **Create Key**
5. Key copy karo — ye `sk-ant-...` se shuru hoti hai
6. **Is key ko kisi ko mat dikhao, kahin public mat daalo**

---

## STEP 2 — Files Netlify pe daalo

### Option A: Drag-Drop (sabse aasaan)
1. **app.netlify.com** pe login karo
2. "Add new site" → "Deploy manually"
3. Ye poora folder (index.html, netlify/, netlify.toml sab) ek saath **drag karke drop** karo
4. Wait karo — site deploy ho jayegi, ek URL milega (jaise random-name.netlify.app)

> ⚠️ Zaroori: folder structure waise hi rakhna. `netlify/functions/analyze.js` isi tarah hona chahiye, warna backend nahi chalega.

---

## STEP 3 — API Key Netlify mein daalo (SAFE tarika)

Ye sabse important step hai — isse "Failed to fetch" fix hoga.

1. Netlify dashboard → apni site kholo
2. **Site configuration** → **Environment variables**
3. **Add a variable** dabao:
   - Key: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-...` (jo aapne STEP 1 mein copy ki)
4. Save karo
5. **Deploys** → **Trigger deploy** → **Deploy site** (taaki key apply ho)

---

## STEP 4 — Test karo

1. Apni netlify URL kholo phone pe
2. Furniture ki photo daalo
3. "AI se Pehchanwao" dabao
4. AI bataye ga konsa furniture hai → sawaal poochhega → costing milegi ✅

Agar abhi bhi "Failed to fetch" aaye:
- Check karo `analyze.js` file `netlify/functions/` folder ke andar hai
- Check karo Environment variable ka naam **exactly** `ANTHROPIC_API_KEY` hai
- Trigger deploy dobara karo

---

## STEP 5 — kaarukranti.in se jodo (optional)

Jab test ho jaye:
1. Netlify → **Domain settings**
2. Apna domain ya subdomain add karo (jaise estimator.kaarukranti.in)
3. DNS instructions follow karo

---

## Kharcha summary
- Netlify: **Free** (aapke traffic ke liye kaafi)
- Anthropic API: **pay per use** — har photo ~₹1-3
- 100 photos/mahina ≈ ₹100-300

---

## Madad chahiye?
Koi step atke toh screenshot bhejo, main exact bata dunga kya karna hai.

— Furniture Kranti Software Setup
